// 账户权限
export enum RoleType {
  boss = 0, // 老板权限 总账号
  shopManager, // 店长账号
  shop, // 收营员
  waiter // 服务员
}
// 是否是灰度商户
export enum GrayUser {
  normal = 0, // 非灰度
  gray // 灰度商户
}
// 是否有押金收款权限
export enum PreAccess {
  normal = 0, // 没有权限
  limit // 有权限
}

// 是否有押金收款权限
export enum perOrder {
  normal = 0, // 没缺陷
  limit // 有权限
}
// 是否有扫码点单权限
export enum ScanOrder {
  normal = 0, // 没权限
  protogenesis, // 有权限 并且是原生
  h5
}

// 是否有特价活动权限
export enum SpecialActivity {
  normal = 0, // 没有活动
  show // 有活动
}
// 是否开启手机号收款
export enum IsOpenCollectByPhone {
  open = 1, // 开启
  default, // 第一次因为要发短信, 所以是2
  close // 关闭
}

// 特价活动入口权限
export enum MarketingActivity {
  open = 1, // 打开
  close = 2 // 关闭
}
